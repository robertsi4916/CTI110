user_input = input()

# print the welcome message with name

print("Hello",user_input,"and welcome to CS Online!")